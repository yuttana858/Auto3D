"""Import integrity, unit handling, failure isolation and output preservation."""

from __future__ import annotations

from dataclasses import replace
from importlib.util import find_spec
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from convert import ConversionError, convert, freeze_source, publish_step, run_worker


class ConverterTests(unittest.TestCase):
    def test_units_must_be_explicit(self):
        with self.assertRaises(ConversionError) as error:
            convert(Path("housing.x_t"), Path("housing.step"))
        self.assertEqual(error.exception.code, "source_unit_required")

    def test_source_copy_is_bounded_and_frozen(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source = directory / "housing.X_T"
            stage = directory / "stage"
            stage.mkdir()
            source.write_bytes(b"immutable")
            frozen = freeze_source(source, stage, 9)
            source.write_bytes(b"changed")
            self.assertEqual(frozen.read_bytes(), b"immutable")
            frozen.unlink()
            with self.assertRaises(ConversionError) as error:
                freeze_source(source, stage, 4)
            self.assertEqual(error.exception.code, "input_too_large")

    def test_empty_and_unrelated_files_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, code in (("file.stl", "unsupported_format"), ("empty.x_b", "empty_input")):
                source = directory / name
                source.touch()
                with self.assertRaises(ConversionError) as error:
                    freeze_source(source, directory, 100)
                self.assertEqual(error.exception.code, code)

    def test_existing_sidecar_prevents_any_output_write(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            output = directory / "existing.step"
            sidecar = directory / "existing.step.conversion.json"
            sidecar.write_text("retain", encoding="utf-8")
            with self.assertRaises(ConversionError) as error:
                convert(directory / "model.x_t", output, "mm")
            self.assertEqual(error.exception.code, "output_exists")
            self.assertFalse(output.exists())
            self.assertEqual(sidecar.read_text(), "retain")

    def test_racing_sidecar_does_not_leave_new_step_or_replace_existing_file(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            stage = directory / "stage"
            stage.mkdir()
            source = stage / "model.step"
            source.write_bytes(b"step")
            Path(str(source) + ".conversion.json").write_text("new")
            destination = directory / "model.step"
            sidecar = Path(str(destination) + ".conversion.json")
            sidecar.write_text("existing")
            with self.assertRaises(FileExistsError):
                publish_step(source, destination)
            self.assertFalse(destination.exists())
            self.assertEqual(sidecar.read_text(), "existing")

    def test_worker_timeout_is_actionable_and_reaps_the_process(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ConversionError) as error:
                run_worker([sys.executable, "-c", "import time; time.sleep(5)"], Path(temporary), 0.05)
            self.assertEqual(error.exception.code, "timeout")


@unittest.skipUnless(find_spec("parasolid_kit") and find_spec("OCP"), "Install pinned native requirements")
class NativeIntegrationTests(unittest.TestCase):
    def test_pinned_runtime_loads_in_bounded_worker(self):
        result = convert(command="doctor", timeout=30)
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["dependencies"]["parasolid-kit"], "0.3.17")

    def test_invalid_text_and_binary_parasolid_return_diagnostics_without_artifacts(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for extension in (".x_t", ".x_b"):
                source = directory / ("invalid" + extension)
                source.write_bytes(b"not a Parasolid transmit file")
                output = directory / (extension[1:] + ".step")
                result = convert(source, output, "mm", timeout=30)
                self.assertFalse(result["ok"], result)
                self.assertTrue(result["error"]["code"])
                self.assertFalse(output.exists())
                self.assertFalse(Path(str(output) + ".conversion.json").exists())
                self.assertFalse(list(directory.glob(".auto3d-parasolid-*")))

    def test_source_inches_and_mm_preserve_topology_and_dimensions_on_step_reimport(self):
        from box_fixture import make_box_model
        from parasolid_kit.interop.limits import InteropLimits
        from worker import convert_brep

        with tempfile.TemporaryDirectory() as temporary:
            for unit, scale in (("mm", 1), ("in", 25.4)):
                destination = Path(temporary) / (unit + ".step")
                report = convert_brep(make_box_model(), destination, unit, "synthetic-box", InteropLimits())
                self.assertEqual(report["status"], "validated")
                self.assertTrue(report["validation"]["process_isolated"])
                self.assertTrue(report["validation"]["topology_matches"])
                self.assertTrue(report["assembly_instances_placed"])
                for actual, dimension in zip(report["dimensions_mm"], (40, 30, 20), strict=True):
                    self.assertAlmostEqual(actual, dimension * scale, places=5)
                sidecar = json.loads(Path(str(destination) + ".conversion.json").read_text())
                self.assertTrue(sidecar["validation"]["passed"])
                self.assertEqual(sidecar["step"]["output_unit"], "mm")

    def test_incomplete_source_never_exports_a_step(self):
        from box_fixture import make_box_model
        from parasolid_kit.interop.limits import InteropLimits
        from parasolid_kit.interop import OcctConversionError
        from worker import convert_brep

        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "incomplete.step"
            with self.assertRaises(OcctConversionError):
                convert_brep(replace(make_box_model(), complete=False), output, "mm", "synthetic-incomplete", InteropLimits())
            self.assertFalse(output.exists())

    def test_rotated_and_translated_assembly_instances_survive_step_reimport(self):
        from box_fixture import _Sources, make_box_model
        from parasolid_kit import Assembly, AssemblyKind, Instance, InstancePartKind, Transform, Vector3
        from parasolid_kit.interop.limits import InteropLimits
        from worker import convert_brep

        model = make_box_model()
        sources = _Sources(1000)
        transforms = (
            (((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)), Vector3(100.0, 0.0, 0.0)),
            (((0.0, -1.0, 0.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0)), Vector3(0.0, 0.0, 50.0)),
        )
        instances = tuple(
            Instance(index, False, InstancePartKind.BODY, model.bodies[0].id,
                     Transform(rotation, translation, 1.0, Transform.TRANSLATION | Transform.ROTATION,
                               Vector3(0.0, 0.0, 0.0), sources.next("transform")),
                     0, sources.next("instance"))
            for index, (rotation, translation) in enumerate(transforms)
        )
        model = replace(model, instances=instances, assemblies=(
            Assembly(0, AssemblyKind.COLLECTIVE, 1000.0, 1e-8, (0, 1), (), sources.next("assembly")),
        ))
        with tempfile.TemporaryDirectory() as temporary:
            report = convert_brep(model, Path(temporary) / "assembly.step", "mm", "synthetic-assembly", InteropLimits())
            self.assertEqual(report["topology"]["solids"], 2)
            self.assertEqual(report["validation"]["actual_topology"]["bodies"], 2)
            for actual, expected in zip(report["dimensions_mm"], (170, 40, 70), strict=True):
                self.assertAlmostEqual(actual, expected, places=5)
            self.assertTrue(report["validation"]["passed"])


if __name__ == "__main__":
    unittest.main()
