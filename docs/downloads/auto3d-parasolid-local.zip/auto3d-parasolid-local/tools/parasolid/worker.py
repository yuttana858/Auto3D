"""Native worker for the local Parasolid import bridge; invoked by convert.py."""

from __future__ import annotations

import argparse
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import sys


def dependencies() -> dict[str, str]:
    expected = {
        "parasolid-kit": "0.3.17",
        "cadquery-ocp-novtk": "7.9.3.1.1",
        "cadquery-ocp-proxy": "7.9.3.1.1",
    }
    actual = {name: version(name) for name in expected}
    if actual != expected:
        raise RuntimeError("Install this converter's pinned requirements.txt first.")
    return actual


def convert_brep(brep, destination: Path, source_unit: str, identity: str, limits):
    """Preserve assembly placements and require complete, validated geometry."""
    from parasolid_kit.interop.occt import to_occt, write_step

    converted = to_occt(
        brep,
        source_unit=source_unit,
        target_unit="mm",
        require_complete=True,
        partial=False,
        heal=False,
        place_instances=True,
        source_identity=identity,
        limits=limits,
    )
    exported = write_step(
        converted,
        destination,
        output_unit="mm",
        validate=True,
        overwrite=False,
        limits=limits,
    )
    validation = exported.report.validation
    if exported.report.status != "validated" or validation is None or not validation.passed:
        raise RuntimeError("STEP cold reimport did not pass validation.")
    bounds = validation.metrics_mm.bounding_box
    return {
        "status": "validated",
        "output_unit": "mm",
        "step_schema": exported.report.step_schema,
        "dimensions_mm": None if bounds is None else [bounds[i + 3] - bounds[i] for i in range(3)],
        "source_complete": converted.report.source_complete,
        "conversion_complete": converted.report.conversion_complete,
        "occt_valid": converted.report.occt_valid,
        "assembly_instances_placed": converted.report.options.place_instances,
        "topology": converted.report.output_topology.to_dict(),
        "validation": validation.to_dict(),
    }


def execute(arguments) -> dict:
    versions = dependencies()
    if arguments.command == "doctor":
        from parasolid_kit.interop.occt import load_runtime
        load_runtime()
        from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
        if BRepPrimAPI_MakeBox(1, 1, 1).Shape().IsNull():
            raise RuntimeError("Native OpenCascade runtime failed its check.")
        return {"ok": True, "status": "ready", "dependencies": versions}

    from parasolid_kit import ParseLimits, read_brep
    source = Path(arguments.source)
    parsed = read_brep(
        source,
        limits=ParseLimits(max_file_size=arguments.max_input_bytes, max_diagnostics=1000),
    )
    result = {
        "ok": True,
        "status": "inspected",
        "dependencies": versions,
        "source": {
            "name": source.name,
            "sha256": hashlib.sha256(parsed.document.raw_bytes).hexdigest(),
            "format": "X_B" if parsed.brep.source_format == "binary" else "X_T",
            "summary": parsed.summary.to_dict(),
        },
    }
    if arguments.command == "inspect":
        # Inspection records unsupported/incomplete geometry; it promises no STEP export.
        return result

    from parasolid_kit.interop.limits import InteropLimits
    result.update(convert_brep(
        parsed.brep,
        Path(arguments.output),
        arguments.source_unit,
        "sha256:" + result["source"]["sha256"],
        InteropLimits(max_output_bytes=arguments.max_output_bytes, max_diagnostics=1000),
    ))
    result["source_unit"] = arguments.source_unit
    return result


def apply_limits(arguments):
    if sys.platform != "linux":
        raise RuntimeError("Run the bounded native worker on Linux (or Linux in Docker/WSL).")
    import resource
    for resource_id, ceiling in (
        (resource.RLIMIT_AS, arguments.memory_bytes),
        (resource.RLIMIT_CPU, arguments.cpu_seconds),
        (resource.RLIMIT_FSIZE, arguments.max_output_bytes),
    ):
        _soft, hard = resource.getrlimit(resource_id)
        effective = ceiling if hard == resource.RLIM_INFINITY else min(ceiling, hard)
        resource.setrlimit(resource_id, (effective, effective))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("doctor", "inspect", "convert"))
    parser.add_argument("--source")
    parser.add_argument("--source-unit", choices=("m", "cm", "mm", "in", "ft"))
    parser.add_argument("--output")
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--max-input-bytes", type=int, required=True)
    parser.add_argument("--max-output-bytes", type=int, required=True)
    parser.add_argument("--memory-bytes", type=int, required=True)
    parser.add_argument("--cpu-seconds", type=int, required=True)
    arguments = parser.parse_args()
    try:
        apply_limits(arguments)
        result = execute(arguments)
    except Exception as error:
        diagnostic = getattr(error, "diagnostic", None)
        result = {
            "ok": False,
            "error": {
                "code": getattr(diagnostic, "code", "conversion_failed"),
                "message": str(error) or type(error).__name__,
                "diagnostic": None if diagnostic is None else diagnostic.to_dict(),
            },
        }
    arguments.result.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
