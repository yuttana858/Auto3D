#!/usr/bin/env python3
"""Local Parasolid -> validated millimeter STEP bridge for Auto3D.

The parent never imports native CAD code. Each job gets a frozen input copy,
bounded Linux subprocess, private staging directory and exclusive output commit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile

MIB = 1024 * 1024
DEFAULT_TIMEOUT = 300
DEFAULT_MAX_INPUT = 128 * MIB
DEFAULT_MAX_OUTPUT = 256 * MIB
DEFAULT_MEMORY = 4096 * MIB


class ConversionError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def freeze_source(source: Path, staging: Path, maximum: int) -> Path:
    if source.suffix.lower() not in (".x_t", ".x_b"):
        raise ConversionError("unsupported_format", "Select a Parasolid .x_t or .x_b file.")
    if not source.is_file():
        raise ConversionError("file_not_found", "The selected Parasolid file does not exist.")
    # Stream the bounded copy: the original may change after stat().
    target = staging / ("input" + source.suffix.lower())
    total = 0
    with source.open("rb") as incoming, target.open("xb") as outgoing:
        while chunk := incoming.read(min(MIB, maximum + 1 - total)):
            total += len(chunk)
            if total > maximum:
                raise ConversionError("input_too_large", f"Input exceeds the {maximum // MIB} MiB limit.")
            outgoing.write(chunk)
    if total == 0:
        raise ConversionError("empty_input", "The selected Parasolid file is empty.")
    return target


def run_worker(command: list[str], staging: Path, timeout: float) -> dict:
    with (staging / "native.log").open("wb") as log:
        process = subprocess.Popen(
            command, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True,
        )
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            raise ConversionError("timeout", f"Conversion exceeded {timeout:g} seconds.") from None
        finally:
            # Include any cold-reimport process left behind after a native crash.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    result_path = staging / "result.json"
    if not result_path.is_file() or result_path.stat().st_size > 16 * MIB:
        raise ConversionError("worker_failed", "Native worker stopped without a bounded result; no output was published.")
    try:
        result = json.loads(result_path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError):
        raise ConversionError("worker_failed", "Native worker returned an invalid result.") from None
    if not isinstance(result, dict) or not isinstance(result.get("ok"), bool):
        raise ConversionError("worker_failed", "Native worker returned an invalid result.")
    if process.returncode != 0 and result["ok"]:
        raise ConversionError("worker_failed", "Native worker failed after returning its result.")
    return result


def publish_step(staged: Path, destination: Path):
    """Hard links are exclusive; rollback only this job's new outputs on failure."""
    published = []
    try:
        for source, target in (
            (staged, destination),
            (Path(str(staged) + ".conversion.json"), Path(str(destination) + ".conversion.json")),
        ):
            os.link(source, target)
            published.append(target)
    except BaseException:
        for path in reversed(published):
            path.unlink()
        raise


def convert(
    source: Path | None = None,
    destination: Path | None = None,
    source_unit: str | None = None,
    *,
    command: str = "convert",
    timeout: float = DEFAULT_TIMEOUT,
    max_input_bytes: int = DEFAULT_MAX_INPUT,
) -> dict:
    if sys.platform != "linux":
        raise ConversionError("linux_required", "Run this native converter on Linux, Docker or WSL.")
    if command not in ("doctor", "inspect", "convert"):
        raise ConversionError("invalid_command", "Use doctor, inspect or convert.")
    if not math.isfinite(timeout) or not 0 < timeout <= 3600:
        raise ConversionError("invalid_timeout", "Timeout must be greater than zero and at most 3600 seconds.")
    if not isinstance(max_input_bytes, int) or not 0 < max_input_bytes <= DEFAULT_MAX_INPUT:
        raise ConversionError("invalid_limit", "Input limit must be between 1 byte and 128 MiB.")
    if command != "doctor" and source is None:
        raise ConversionError("missing_input", "Select a Parasolid file.")
    if command == "convert":
        if source_unit not in ("m", "cm", "mm", "in", "ft"):
            raise ConversionError("source_unit_required", "Specify the source coordinate unit: m, cm, mm, in or ft.")
        if destination is None or destination.suffix.lower() not in (".step", ".stp"):
            raise ConversionError("invalid_output", "Choose a .step or .stp destination.")
        destination = destination.absolute()
        if not destination.parent.is_dir():
            raise ConversionError("output_directory_missing", "Create the output directory first.")
        if any(path.exists() or path.is_symlink() for path in (destination, Path(str(destination) + ".conversion.json"))):
            raise ConversionError("output_exists", "STEP or report already exists; choose a new output name.")
    with tempfile.TemporaryDirectory(prefix=".auto3d-parasolid-", dir=None if destination is None else destination.parent) as temporary:
        staging = Path(temporary)
        arguments = [
            sys.executable, str(Path(__file__).with_name("worker.py")), command,
            "--result", str(staging / "result.json"),
            "--max-input-bytes", str(max_input_bytes),
            "--max-output-bytes", str(DEFAULT_MAX_OUTPUT),
            "--memory-bytes", str(DEFAULT_MEMORY),
            "--cpu-seconds", str(math.ceil(timeout)),
        ]
        frozen = None
        if source is not None:
            frozen = freeze_source(source, staging, max_input_bytes)
            arguments += ["--source", str(frozen)]
        staged = None
        if command == "convert":
            staged = staging / destination.name
            arguments += ["--source-unit", source_unit, "--output", str(staged)]
        result = run_worker(arguments, staging, timeout)
        result["schema_version"] = 1
        if source is not None and result.get("source"):
            result["source"]["name"] = source.name
        if not result["ok"] or command != "convert":
            return result
        if not (
            result.get("status") == "validated"
            and result.get("source_complete") is True
            and result.get("conversion_complete") is True
            and result.get("occt_valid") is True
            and result.get("output_unit") == "mm"
            and result.get("validation", {}).get("passed") is True
            and result.get("source", {}).get("sha256") == digest(frozen)
        ):
            raise ConversionError("validation_failed", "Conversion evidence is incomplete; no output was published.")
        if not staged.is_file() or not Path(str(staged) + ".conversion.json").is_file():
            raise ConversionError("missing_output", "Native worker did not produce STEP and validation evidence.")
        if staged.stat().st_size == 0 or staged.stat().st_size > DEFAULT_MAX_OUTPUT:
            raise ConversionError("invalid_output", "Converted STEP is empty or exceeds the output limit.")
        try:
            publish_step(staged, destination)
        except FileExistsError:
            raise ConversionError("output_exists", "An output appeared during conversion; existing files were preserved.") from None
        result["output"] = {
            "path": str(destination),
            "report_path": str(destination) + ".conversion.json",
            "bytes": destination.stat().st_size,
            "sha256": digest(destination),
        }
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("doctor", "inspect", "convert"))
    parser.add_argument("source", nargs="?", type=Path)
    parser.add_argument("--output", "-o", type=Path)
    parser.add_argument("--source-unit", choices=("m", "cm", "mm", "in", "ft"))
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    arguments = parser.parse_args()
    try:
        result = convert(arguments.source, arguments.output, arguments.source_unit, command=arguments.command, timeout=arguments.timeout)
    except (ConversionError, OSError) as error:
        result = {"schema_version": 1, "ok": False, "error": {"code": getattr(error, "code", "io_error"), "message": str(error)}}
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
