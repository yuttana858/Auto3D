# Auto3D Parasolid import bridge

Local evaluation setup for **`.x_t` / `.x_b` → validated AP242 STEP → Auto3D's existing STEP importer**. This native tool is separate from the browser build and the legacy Node Library backend. It does not enable Parasolid in the production file picker or deploy a service. Validate representative supplier files before integrating an authenticated conversion endpoint.

## Keep the CAD file on your own computer

Run this tool on your own Linux computer, or Windows with WSL. The Codex development workspace used to prepare it is cloud-hosted; running a file in that workspace is different from running it on your computer. If the design must stay on your device, keep it out of chat attachments and external conversion services.

1. Download/extract the tool and install the pinned dependencies using the commands below. Installation downloads software; your CAD file is not needed for installation.
2. Choose a local working folder outside automatically synchronized cloud folders. Keep the CAD file and output there.
3. After installation, disconnect networking for the conversion. The converter, native CAD libraries and STEP reimport run locally with no upload/account/API step.
4. Run `doctor`, then `inspect` and `convert` as shown below. The original stays unchanged; STEP and its JSON report are written to your chosen output folder. Working copies and logs are local too; temporary staging is removed after the job finishes normally.

No public website or listening service is started by these commands. Using the open-source program does not publish your CAD input or output. The Git-ignored `private/` and `out/` directories prevent routine Git inclusion; Git ignore alone does not stop cloud-folder synchronization.

This device-only scope covers the command-line converter. Importing into the hosted Auto3D app, account saves, sharing, AI tools and agent access are separate workflows; this setup does not certify them as offline or device-only. Keep the test local until the desired app workflow is verified.

## Install and check

Use Python 3.11 or 3.12 on Linux, including WSL. From the repository root:

```bash
python3 -m venv tools/parasolid/.venv
tools/parasolid/.venv/bin/python -m pip install --only-binary=:all: -r tools/parasolid/requirements.txt
tools/parasolid/.venv/bin/python tools/parasolid/convert.py doctor
tools/parasolid/.venv/bin/python -m unittest discover -s tools/parasolid/tests -v
```

`doctor` checks the exact dependency versions and loads the native OpenCascade runtime. The converter runs each inspection/conversion in a subprocess with a 300-second wall timeout, a 4 GiB address-space ceiling, a CPU limit and a 256 MiB per-file output ceiling. Input is limited to 128 MiB. Limits are development defaults to benchmark with real inputs, not a production throughput promise.

## Inspect and convert a test file

Keep private files under `tools/parasolid/private/` (Git ignored), or outside the repository. Inspection does not require units and reports the source schema, body/geometry counts and completeness:

```bash
mkdir -p tools/parasolid/private tools/parasolid/out
tools/parasolid/.venv/bin/python tools/parasolid/convert.py inspect tools/parasolid/private/product.x_t
tools/parasolid/.venv/bin/python tools/parasolid/convert.py convert tools/parasolid/private/product.x_t --source-unit m --output tools/parasolid/out/product.step
```

**Set `--source-unit` to the actual unit of the Parasolid coordinates.** `m` above is an example, not a default. Choices are `m`, `cm`, `mm`, `in`, `ft`. Units are never inferred. Ask the supplier or compare a known dimension when they are unknown. Output STEP declares millimeters, matching Auto3D's existing importer.

On success the command returns JSON including SHA-256, measured X/Y/Z extents in mm, topology and separate-process STEP reimport evidence. It writes `product.step` and `product.step.conversion.json`. Existing STEP/report files are never overwritten. Source bytes remain unchanged. No file is sent to an external converter or stored in an account Library automatically.

Open the resulting `.step` with Auto3D's existing **Add model** action, check it against a known product dimension and inspect curved surfaces, openings and assembly placements. Auto3D tessellates imported STEP for its scene; retain the original Parasolid and converted STEP for source CAD fidelity. This bridge does not add STEP export from Auto3D's editable mesh scene.

## Conversion contract

- A frozen, size-bounded source copy is parsed with `parasolid-kit` 0.3.17. Its schema/geometry support is a subset of Parasolid; unsupported files produce diagnostics rather than a success placeholder.
- Assembly instances are explicitly placed. STEP contains geometry/topology, not feature history, PMI, colors or a full CAD assembly product hierarchy.
- Conversion requires a complete source and valid OCCT result. Partial conversion and automatic healing are disabled.
- STEP is reopened in a separate OCCT process. Units, nonempty geometry, topology and geometric metrics must pass before outputs are published.
- A timeout/native crash leaves no final STEP/report. Staging is removed after each attempt. Exit code 0 means the requested operation succeeded; conversion success additionally requires `status: "validated"`. Inspection success alone does not certify convertibility.
- JSON has `schema_version: 1`, `ok`, and either result fields or an actionable `error.code` / `error.message` / optional diagnostic. Units and source SHA are recorded in the conversion sidecar.

The tests verify bounded/frozen input, existing-file preservation, timeout behavior, invalid text/binary inputs, native runtime loading, rejection of incomplete geometry, a synthetic typed B-Rep box converted from mm and inches, and rotated/translated assembly instances through STEP cold reimport. **The box fixture bypasses the Parasolid parser.** Real `.x_t` / `.x_b` positive-path acceptance remains dependent on supplier samples.

## Integration after sample acceptance

The user prefers on-device conversion for confidential CAD. Keep the native worker on the user's computer for the test; a future local companion integration should preserve that boundary. Do not switch confidential inputs to a cloud conversion service automatically. A Pages Function itself cannot load these native Python/OCCT wheels. Any future remote conversion path requires an explicit user upload and account-owned, bounded jobs. Add a stable shared command and catalog entry for a new app action, then pass only successfully validated millimeter STEP to the existing importer. Do not advertise `.x_t` / `.x_b` in `ModelExtensions` until that workflow is available. No authentication, database, Library, module or deployment changes are needed for this local test setup.

## Upstream and licensing

- [parasolid-kit](https://github.com/monozukuri-ai/parasolid-kit): pinned distribution 0.3.17; `MIT AND Apache-2.0`. Consult the pinned release rather than assuming newer main-branch geometry fixes are included.
- [cadquery-ocp-novtk / OCP](https://github.com/CadQuery/OCP): pinned wheels 7.9.3.1.1; distribution metadata declares Apache-2.0. The underlying [OpenCascade license and exception](https://dev.opencascade.org/resources/licensing) also apply when distributing its runtime.
- The synthetic box fixture is adapted from upstream `tests/_occt_fixtures.py` at commit `b91972a1ff86d8c8b55b07516923f7c35bfedf77`; its MIT notice is in `tests/FIXTURE-LICENSE.txt`.

These optional native dependencies are not bundled into or added to Auto3D's browser/npm dependencies.
