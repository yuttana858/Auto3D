# Auto3D local Parasolid converter

This source-only package runs on your own Linux computer or Windows with WSL,
using Python 3.11 or 3.12. Install its pinned native dependencies once, then
conversion can run offline. Your CAD input is not needed during installation.

Extract this archive and work from the auto3d-parasolid-local directory.
Read tools/parasolid/README.md for the installation, inspection and conversion
commands. All example commands in that README run from this directory.

Keep confidential input and output on a local disk outside cloud-sync folders.
Do not attach a device-only CAD file to chat or an external conversion service.
The development workspace in which this package was prepared is cloud-hosted;
this archive is intended to move the program onto your own computer.

This archive contains code, documentation, dependency pins and synthetic tests.
It contains no customer CAD, generated CAD output, environment or credentials.
Software dependencies are downloaded during installation; they are not included.
Native conversion and STEP validation use local processes, with no upload step.

Hosted Auto3D, account saves, sharing, AI and agent tools are separate workflows.
This offline converter package does not certify those workflows as device-only.
