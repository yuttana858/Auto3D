# Account board catalog and CSV editing

Auto3D 0.39.0 / Packaging 1.9.0.

Each account has a reusable catalog of board records. Packaging shows grouped E/B/C/EB/BC choices. Select a board for the next generated box, or select it under Selected box to explicitly update the linked model. Caliper is read from the record rather than a separate right-panel numeric input. Advanced per-design measured values remain available in the CAD Measurement layer.

Open the gear beside Board to view/edit CSV. **Open CSV file** replaces only the editor draft, **Download CSV** exports validated content, and **Save database** persists it to the signed-in account. Saving the catalog does not rewrite an existing box: each model carries a material snapshot. Re-select a record to apply new catalog values to that model, with Undo. Nominal entries are not supplier-certified data; supply measured caliper, component paper properties and process tolerances for engineering work.

The CSV contains ID/name/flute, caliper and caliper tolerance, liner/medium grades/GSM/calipers, flute pitch/direction, score width/tolerance, residual process tolerance, conditioning, process/provenance and calibration status. Header order may change, but every supported column must appear exactly once. Quotes, commas and newlines follow CSV escaping. Numeric cells must be finite; booleans are `true`/`false`; IDs must be unique. There must be 1–32 records within 64 KiB. Paper calipers must fit within board caliper; generation supports 0.5–15 mm caliper. Allowance factors intentionally remain per design/style and are not CSV catalog columns.

`modules/packaging/src/boarddatabase.js` owns defaults, CSV and validation; `boarddatabasepanel.js` owns the neutral editor. `panel.js` owns grouped selectors and W/L/H rows. No module code imports the app engine/auth/database provider. Auto3D's `AccountBoardDatabase` service and PackagingWorkspace bridge account persistence and scene updates. Standalone hosts can supply board storage/editor callbacks; without them the neutral preview uses an in-memory catalog.

`GET/PUT /api/packaging/boards` is behind the existing verified-session middleware. Every query is scoped to `data.user.id`; client owner fields are rejected. PUT requires the application origin, validates the complete catalog, and conditionally updates only the board JSON field against its previous revision. A stale save returns 409. The editor retains unsaved text on errors; reopen to load the latest revision. Client responses are rejected after account changes. No browser service key or direct table permission is introduced.

Migration `database/20261027185638_account_board_catalog.sql` mirrors the applied Supabase-generated migration version. It adds nullable `public.auto3d_preferences.board_database`; NULL means app nominal defaults. Do not replay historical PR16 SQL. Existing account preference/folder updates select/update their own columns and cannot overwrite the board field. Catalog requests are private/no-store. Existing RLS and service-only grants remain unchanged.

Agent commands share the same service and editor callbacks: `packaging.boards.inspect`, `packaging.boards.select {id,target}`, `packaging.boards.open`, `packaging.boards.export`, and `packaging.boards.save_csv {csv,revision?}`. `target` is `generation` or `selected`; first revision may be null. The schema is strict; saves are awaited and conflict-aware. Agent macros may use the exported CSV/revision, edit the CSV externally, then explicitly save.

## Board grades and basis-weight combinations

The shipped E/B/C/EB/BC rows are nominal flute/caliper references, not a supplier-certified ECT grade database. Paper grade names and outside/medium/inside GSM are editable already. There is currently no separate numeric ECT rating/test-method field. Record a supplier's declared grade in the board name/provenance and keep its measured caliper; do not infer caliper or a guaranteed ECT from paper weights alone.

For a supplier specification written **B flute · 32 ECT · 32-28-32**, confirm its units and layer order. In common US containerboard notation, the three figures describe **outside liner / medium / inside liner**, in pounds per 1,000 square feet of the unfluted paper. They are distinct from the board's edge-crush rating. `GSM = lb/MSF × 4.882427636`; consequently, 32-28-32 corresponds to approximately **156.24 / 136.71 / 156.24 GSM**. These conversions identify paper basis weights; they do not certify that this combination achieves 32 ECT. Different fiber furnish, paper compression strength, flute formation, adhesive, humidity and converting processes affect performance. Double wall requires five constituent paper layers; the current three-paper specification is an approximation for EB/BC.

Sources reviewed 2026-10-27: [President Container Group — basis weight and grade distinctions](https://www.presidentcontainergroup.com/basis-weight/), [Fibre Box Association — ECT Application and Reference Guide](https://store.fibrebox.org/products/ect-application-and-reference-guide-1), and [Virginia Tech research on component basis-weight notation](https://www.unitload.vt.edu/content/dam/unitload_vt_edu/graduate-research-and-subpages-pictures-and-docs/thesis-and-dissertations-/Park%20-%20ETD%20-%20Investigation%20of%20fundemental%20relationships%20to%20improve%20the%20sustainability%20of%20unit%20loads.pdf). The FBA guide is a reference listing; its purchased performance tables have not been imported. No nominal catalog row is relabeled as a tested grade.
# Development note: multiwall previews and board changes

The local Packaging changes add ACA and BCB nominal starting records alongside
EB and BC. Existing saved account catalogs are not overwritten; users can add
their own records through the CSV editor. Nominal calipers are placeholders,
not certified grades or supplier measurements. Supply measured caliper and
converter-approved allowances for production work.

The exposed-edge texture illustrates intermediate liners and multiple media
for EB, BC, ACA and BCB. Individual wall heights, intermediate liner thickness
and flute pitches are approximated for display, not manufacturing inputs.
Sheet direction continues to drive the edge texture mapping. CAD measurements
remain based on the canonical profile and its engineering allowances.

For a selected generated box, changing its board recalculates score spans to
preserve the current inside or outside dimensions. This requires usable
allowance factors for the chosen basis. Uncalibrated zero factors are rejected;
the update leaves the model unchanged. Auto dimensions become manual targets
when the selected board is changed; parametric dimensions remain parametric.
New-box fields default to inside (ID). Switching basis converts the draft when
the current style and board have the necessary factors; otherwise the user
must enter new targets. FEFCO 0201 has a reference inside allowance; OD and other
styles require converter-supplied allowances in the selected matching box's
Measurement layer. The preset command accepts an explicit inside/outside basis;
omitting it retains the existing score-to-score API behavior. Generated CAD
measurements default to inside for new generated profiles; previously saved
measurement bases remain intact.
