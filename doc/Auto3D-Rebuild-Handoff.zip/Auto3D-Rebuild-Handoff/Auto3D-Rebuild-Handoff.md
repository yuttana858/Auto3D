# Auto3D rebuild and migration handoff

Assessment date: November 5, 2026. Repository: `yuttana858/Auto3D`.

**Recommendation:** preserve Auto3D's document, geometry, manufacturing, identity, and storage services as deterministic components. Build the new agentic harness around their validated command contracts. Replacing those services with agent reasoning would introduce compatibility, security, and engineering risks.

This document compiles the assessment delivered in chat. Supporting repository documentation is included separately, unchanged, and can contain outdated or conflicting claims. Use the evidence labels and baseline below to interpret it.

## 1. Evidence, scope, and confidence

- **Verified:** directly supported by inspected code, configuration, tests, repository metadata, or live database metadata.
- **Inferred:** a reasonable interpretation without direct user or business confirmation.
- **Proposed:** a recommendation for the rebuild.
- **Unknown and requiring confirmation:** evidence is missing, conflicting, or insufficient.

### Verified baselines

| Material | Baseline/result |
|---|---|
| Local checkout | `716ed51b48f88caeb5b147e1d4b6cc206c35358e`; working tree clean at assessment |
| Remote main | Latest returned commit `8697574620d7d11a1e3532dfdacd0d20e42b293b`, merging PR #69 |
| Application version | 0.47.6 in inspected local and remote package.json |
| Packaging | 1.10.3 |
| Primary Products in local baseline | 0.1.0, draft UI package |
| Command catalog | API version 1; 250 commands |
| Connected database | Auto3d Supabase project; PostgreSQL 17; schema/migration metadata inspected |
| Application tests | 720 passing |
| Application lint | Passed |
| Focused tests | 22 passing |
| Backend tests | HTTP tests blocked by localhost socket restriction, listen EPERM |
| MCP | Worker build completed; 10 tests passed; runtime setup/cleanup blocked by localhost restriction |

Sources: package.json, modules/packaging/package.json, modules/primary-products/README.md, website/assets/commands.json, repository metadata, and assessment-time test/tool results. Paths are relative to the repository. See Source-Index.md for pinned links and evidence locations.

**Verified scope:** source structure, product/technical documentation, database definitions and live schema metadata, deployment workflows, command contracts, tests, recent PRs, and the supplied stability review were reviewed. No production data, credentials, or permissions were changed.

**Unknown:** exact currently served production commit; real-client MCP acceptance; real Meshy-key acceptance/paid generation; physical mobile behavior; production restore capability; fidelity against representative corporate CAD assets. Issue search returned no issue records; PRs/documents supplied available change history. Metadata counts are not adoption analytics.

**Unknown and requiring confirmation:** new harness, target hosting, deadline, users, business-critical workflows, and service objectives. The final user working rule was truncated; preservation of existing outcomes and externally observable behavior is assumed unless retirement is explicitly approved.

## 2. Product, users, and business processes

**Verified:** Auto3D is an Online3DViewer-derived browser 3D viewer/editor. It imports CAD/mesh assets, assembles scenes, edits objects/materials, generates corrugated packaging, authors animation/presentations, renders PNGs, saves portable/account/device projects, shares read-only snapshots, integrates Meshy, and exposes authorized agent commands. Source: docs/agent-project-overview.md.

| Process | Supported outcome | Evidence status |
|---|---|---|
| Import, inspect, edit, save | Editable multi-object scene | Verified |
| Generate packaging, inspect CAD, adjust, export | Concept geometry and authoritative vectors | Verified |
| Assemble layouts | Arrays, groups, placement and presentation | Verified |
| Save, reopen, reuse | Portable files, device and account Library | Verified |
| Share saved work | Independent code-protected read-only snapshot | Verified |
| Generate AI asset, preview, save/add | Meshy assets enter editable workflow | Verified implementation; live provider acceptance unknown |
| Authorize agent, pair window, operate | Commands target selected live session | Verified implementation; real-client acceptance unknown |

**Inferred personas:** packaging specialist/designer; scene/layout author; reviewer/external recipient; administrator; agent-assisted operator. These follow implemented workflows, not confirmed customer segments. Usage frequency and commercial importance remain unknown. Sources: docs/packaging-module.md, docs/audience-sharing.md, docs/ai-generative.md, docs/mcp-pilot.md.

## 3. Architecture and boundaries

**Verified:** JavaScript ES modules, imperative DOM, Three.js, CSS, fflate and Pickr; not React. Production is documented as Cloudflare Pages/Functions, private R2 and Supabase Auth/PostgreSQL. The Node backend is an alternate Library API, not the deployed Pages app's internal service. Source: docs/agent-project-overview.md.

```mermaid
flowchart TD
 UI[Browser workspaces] --> Commands[Shared command registry]
 UI --> Services[Scene / materials / packaging / animation]
 Commands --> Services
 Services --> Engine[Geometry engine and Three.js]
 Services --> Archive[Archive and recovery workers]
 Archive --> Device[IndexedDB / downloaded files]
 UI --> API[Same-origin Pages APIs]
 API --> Identity[Supabase identity / metadata]
 API --> R2[Private R2]
 API --> Meshy[Meshy]
 Agent[OAuth MCP client] --> Broker[Authorization and broker]
 Broker --> Commands
```

**Proposed boundaries to retain:** document/geometry core; neutral independent Packaging domain module; guarded application services; identity/storage adapters; agent adapter; presentation layer. Frameworks and hosting can change without combining these responsibilities.

## 4. Capability inventory and disposition

All priorities/dispositions are **Proposed**, based on data-loss/security/domain risk, not verified user-frequency rankings. Capabilities are **Verified** at the inspected baseline except explicitly limited draft/future items. Sources: docs/agent-project-overview.md, docs/agent-interface.md, website/assets/commands.json and feature documents below.

| ID | Capability / implementation | Contract to preserve | Disposition |
|---|---|---|---|
| F01 | Import; importformats.js, engine importers | Formats, sidecars, multi-object import, clear errors | P0 compatibility |
| F02 | sessioneditor.js, scenedocument.js | Select/transform/duplicate/hide/delete, placement-preserving source update, history | P0 port |
| F03 | arraylayout.js, groups | W/L/H, layer rotation, identities, grouping, bounds spacing | P1 preserve |
| F04 | sessionarchive.js | Versioned embedded archives and validation | P0 preserve external contract |
| F05 | sessionrecovery* | Account/device checkpoints, workers, safe restore/discard | P0 preserve |
| F06 | sessiontabs.js | Independent state/history, dirty close, account clipboard | P1 preserve |
| F07 | materialpanel.js, materialtextures.js | PBR/Phong maps, UVs, source bytes, reversible edits | P0 fidelity |
| F08 | Packaging relief/appearance | Corrugation, impressions, varnish, crease presentation independent of CAD | P1 preserve |
| F09 | Lighting/effects | HDRI, backgrounds/grid, ambient, reflections, floor shadows | P1 preserve outcome |
| F10 | Cameras/navigation | Named views, FOV/projection, focus/orbit, touch/desktop | P1 preserve |
| F11 | sessionanimation.js | Embedded skeletal/morph clips/resources, paused reopen | P1 preserve |
| F12 | sessiontimeline.js, timelineactions.js | Object/camera tracks, interpolation/range, fold actions | P1 preserve |
| F13 | renderqueue.js, rendercore.js | Tiled PNGs, alpha, cameras, cancel/image lifecycle | P1 preserve |
| F14 | polygonoptimizer.js/worker | Preview/apply/cancel, revision checks, Undo, animation exclusion | P1 controlled lossiness |
| F15 | Auth/account admin | Approved accounts, verified active sessions, revoke/reset | P0 security |
| F16 | Account Library/API | Owner-scoped files, folders, quotas, pending/ready lifecycle | P0 preserve |
| F17 | Device Library/preferences | Account scoping, folders, units/theme/view | P0 preserve |
| F18 | Audience/mini viewer | Snapshot, code, expiry/revoke, download permission | P0 preserve |
| F19 | CloudLibrary/legacy shares | R2 and legacy Storage authorized reads | P1 retain until audited |
| F20 | Packaging CAD/extrusion | Canonical mm, paths/holes, vectors, profiles | P0 deterministic |
| F21 | FEFCO generation/folding | 0200-0203, saved dielines, caliper, guarded playback | P0 deterministic |
| F22 | engineering.js | Allowances, tolerances, bases and driven targets | P0 deterministic |
| F23 | Board catalog/API | CSV validation, revisions, material snapshots | P0 preserve |
| F24 | AI workspace | Six Meshy workflows, preview and downloaded durable projects | P1 provider adapter |
| F25 | AI credentials | Interactive encrypted account keys and fail-closed rules | P0 security |
| F26 | CommandRegistry/macros | Stable strict schemas, shared services, sequence/partial results | P0 API |
| F27 | MCP | OAuth, window/session pairing, revoke/capture permissions | P0 adapter/acceptance |
| F28 | Diagnostics/capture | Bounded local sanitized logs and private-field exclusion | P1 preserve |
| F29 | Packaging knowledge | Search/provenance/limitations | P1 preserve content |
| F30 | Primary Products | Draft bottle/can UI, disabled scene generation | P2 verified draft only |

**Verified formats:** 3dm, 3ds, 3mf, amf, bim, brep, dae, fbx, fcstd, gltf/glb, ifc, iges/igs, step/stp, stl, obj, off, ply, wrl, zae; ZIP and auto3d advertised by UI. Declared support does not prove equal fidelity. Sources: source/website/importformats.js, docs/pretransition-readiness.md.

**Verified export distinction:** mesh exports are not replacements for editable .auto3d. Some Auto3D material data is represented in glTF extras other viewers may ignore. Sources: README.md, docs/surface-relief.md.

## 5. Critical contracts and hidden behavior

### 5.1 Portable documents and recovery

**Verified:** SessionVersion is 5, despite the format document describing v4. Older supported versions migrate sequentially; newer unsupported files fail clearly. Local archive limits are 256 MiB; scenes cap at 1,000 objects. Validation precedes replacement. Source: source/website/sessionarchive.js.

Preserve geometry/hierarchy; materials/maps/embedded bytes; transforms/visibility/custom metadata; animation resources/settings; view/lighting/cameras; keyframes/actions; packaging/engineering snapshots; profile-only sessions; explicit errors; non-destructive in-memory migration.

**Verified hidden repair:** older asynchronous saves could encode multiplyDiffuseMap=true as {buffer:null}; the reader repairs that precise value. Retain it or supply an explicit migration. Sources: sessionarchive.js, PR #61.

**Verified:** recovery is local/account-scoped; valid work is retained until explicit save/discard; restore cannot overwrite unsuitable workspaces. Workers and geometry-snapshot reuse mitigate UI stalls. Sources: docs/account-storage.md, sessionrecovery*.js.

**Proposed:** golden archives for every supported version, malformed material repair, animation, profile-only, board snapshots and large files.

### 5.2 Units and coordinates

**Verified:** unknown units stay model units; packaging is canonical mm; preferences alter input/display rather than geometry; W=X, L=Z, H=Y; legacy object.transform defaults to model coordinates, selection.transform to display units. Packaging commands have documented mm/display differences. Complete true Z-up migration is not established. Sources: docs/polygon-optimization.md, docs/packaging-module.md, PR #51.

**Proposed:** explicit unit types/conversion boundaries; retain defaults or version changes. Never guess source physical units.

### 5.3 Scene consistency and completion

**Verified:** services coordinate engine/render state, selection/history/dirty/serialization. Library Add stages fresh identities, commits one Undo step and rolls back failures. Async work rechecks account/workspace. Source: docs/audience-sharing.md.

**Verified:** dialog-open is not file-save completion; render/fold start is not completion; fold finishing/cancelling/restoring states precede final states. Macros stop on failure and keep completed changes, with no transaction rollback. Source: docs/agent-interface.md, commandregistry.js.

**Proposed:** explicit operation IDs, final states, cancellation semantics and account/document revisions.

### 5.4 Packaging engineering

**Verified:** CAD/engineering specifications, not rendered bounds/textures/deformation, govern manufacturing dimensions. Sources: docs/corrugated-dimensions-and-creases.md, modules/packaging/src/engineering.js.

- Inside: I = S - factorInside * caliper.
- Outside: O = S + factorOutside * caliper.
- Inside target: S = targetInside + allowanceInside.
- Outside target: S = targetOutside - allowanceOutside.
- Conservative tolerance: scoreTolerance + abs(factor)*caliperTolerance + processTolerance.

**Verified rules:** default [1,1,2] inside factors apply to identified 0201 reference behavior, not every style; outside factors start at zero; uncalibrated zero factors cannot drive ID/OD targets; user calibration is not certification. Auto reads, Manual drives once, Parametric holds targets through material changes. Reject conflicts/dangling references. Generic scale is not a manufacturing dimension edit.

**Verified:** SVG physical mm/CUT-SCORE groups; DXF mm/layers; even-odd contour holes; invalid/self-crossing/touching contours refused before mutation. Score metadata is not a general fold solver. Arbitrary dieline edits cannot infer supported hinge routes. Fold collision audit covers generated box panels, not the full scene. Sources: docs/packaging-module.md, agentcommands.js.

**Verified:** existing boxes retain material snapshots. Catalog changes do not rewrite them. Applying revised board data is explicit/Undoable. Catalog saves use revisions and 409 conflicts; no silent local-only save after API failure. Sources: docs/board-database.md, AGENTS.md.

**Proposed:** initially port the independent neutral Packaging API/tests/build boundary intact.

### 5.5 Appearance, rendering and animation

**Verified:** floor shadows are projected silhouettes, not general physical self-shadows; relief/creases do not alter authoritative CAD. Render queues tile locally, restore state after failure/cancel, and keep transient local images. Large outputs remain memory-bound. Sources: docs/rendering.md, docs/surface-relief.md.

**Verified:** embedded animation and native object/camera timelines are independent; reopen paused. Array creation animation is not an exported clip. Sources: docs/native-keyframe-animation.md, docs/agent-interface.md.

**Proposed:** reference-image/state comparisons covering capture failure, cancel, previews/context loss, folding and timeline seeking.

## 6. Data model and migration

**Verified:** live metadata includes active account features and older organization foundations. Returned metadata reported three personal Library rows and five audience-share rows; this is stored-record evidence, not adoption analytics. No model payloads or credential records were read. Sources: assessment Supabase list_tables/list_migrations results.

| Domain | Current storage | Migration obligation |
|---|---|---|
| Identity | Supabase Auth UUID | Stable internal ownership mapping |
| Access | account_controls, active-session RPC | Disable and session cutoff |
| Admin/requests | admin_emails, access_requests | Verified current workflow |
| Preferences | preferences + folders + board_database | Full fields/revisions |
| Personal Library | personal_library + private R2 | Metadata/archive/thumbnail consistency |
| Audience | shares/attempts + snapshots | Expiry/revoke/code/throttle/download |
| Legacy | library/share tables + R2/Storage | Audit references before retirement |
| Environments | table + packaged previews | Fallback/provenance |
| AI keys | Dedicated encrypted R2 | Isolated migration or re-entry |
| Device work | Account-scoped IndexedDB | Browser export/import |
| Portable files | User .auto3d files | Compatible reader |
| Agent state | OAuth KV / Durable Objects | Explicit migration or reconsent |

**Verified:** ownership is UUID-based, not email. Personal binaries/thumbnails are owner-filtered. Legacy unassigned browser storage is not automatically claimed. Source: docs/account-storage.md.

**Verified limits:** account archive 32 MiB; PNG 1 MiB; account reservation budget 1 GiB/1,000 saves; separate audience budget 1 GiB/1,000 retained snapshots. Pending reservations count. Saves become visible after required writes. Failed cleanup retains pending records. Folder deletion moves items upward. Multi-item moves can partially succeed. Sources: docs/account-storage.md, docs/audience-sharing.md.

**Verified schema-history risk:** applied history spans supabase/migrations and database SQL; live audience version differs from source filename. Historical PR16 SQL is not a bootstrap and must not replay. Sources: docs/pr16-reconciliation.md, live migrations, docs/board-database.md.

**Proposed sequence:** inventory schema/grants/RPCs; create clean bootstrap; consistent DB/object backup; stable identity map; checksummed object copy; preserve or intentionally invalidate capabilities; browser device-data migration before origin change; old/new compatibility tests; reconcile pending/orphans; retain rollback-compatible data.

**Unknown:** retention, RPO/RTO, deletion obligations, existing-link survival requirements.

## 7. APIs and integrations

**Verified API responsibilities** (sources: docs/agent-project-overview.md, functions/api/_middleware.js, feature documents):

| Surface | Responsibility / contract |
|---|---|
| /api/auth/* | Login/session/logout/recovery; server verification |
| /api/accounts/* | Requests/approvals/admin authorization |
| /api/personal/* | Owned saves/binaries and reservations |
| /api/preferences | Identity-safe preference synchronization |
| /api/packaging/boards | Strict revision-controlled catalog |
| /api/library/*, /api/share/* | Legacy published access |
| /api/audience/* | Snapshot challenge and narrow anonymous exceptions |
| /api/ai/* | Meshy proxy/credentials; allowlists/bounds/redaction |
| /api/environments | Catalog with packaged fallback |
| /api/knowledge/paper-packaging | Provenance-bearing reference content |
| /mcp and OAuth/agent routes | Resource/account/window/session authorization |

**Verified Meshy:** Text to 3D preview/refine, Image to 3D, Text to Image, Retexture, humanoid Rigging, Animation. Other provider APIs mentioned in docs are not wired by implication. Opening/changing UI must not create paid tasks. Completed model downloads are embedded for durable projects; pending tasks/generated image bytes are not included; failed download blocks incomplete save. Old provider actions may expire even when downloaded project reopens. Source: docs/ai-generative.md.

**Verified:** alternate Node backend Entra roles do not establish browser Entra login or full deployed personal-account parity. Sources: backend/README.md, GOAL.md.

**Unknown:** additional enterprise integrations/webhooks/downstream manufacturing dependencies not evidenced here.

## 8. Security, privacy, identity, compliance and licensing

### S01: Verified legacy database privilege issue

Read-only role_table_grants returned SELECT, REFERENCES, TRIGGER and TRUNCATE on public.auto3d_library for anon/authenticated. has_table_privilege confirmed effective TRUNCATE and SELECT for both. No destructive/exploit test occurred. API exploitability remains unknown.

**Proposed P0:** separately reviewed least-privilege remediation; do not reproduce excess grants. Evidence: assessment-time live SQL results in evidence/Live-Database-Metadata.json.

### S02: Verified private server boundary

Middleware verifies user/active session, checks account mismatch and same-origin mutations. Cookies are Secure/HttpOnly/SameSite. Returned public Auto3D tables have RLS; inspected public Auto3D RPCs are invoker functions without anon/authenticated EXECUTE. This is not a complete audit. Sources: functions/_lib/auth.js, session.js, functions/api/_middleware.js, live metadata.

### S03: Verified audience controls

Codes include leading zeros and stay out of QR URLs. Five failures/share/IP in 15 minutes lock actor 30 minutes; thirty aggregate failures/share in 15 minutes lock link 30 minutes; success does not reset aggregate failures; missing trusted IP fails closed. Pending/revoked/expired shares deny access. Saved archive snapshots are independent of later edits/deletion. Expired snapshots consume quota until revoked; scheduled cleanup is future work. Download-hidden is UX, not DRM. Source: docs/audience-sharing.md.

### S04: Verified AI vault boundary

Account-bound AES-256-GCM in dedicated private R2, fresh IV and path binding, no saved-key return, no command/macro key input. Corrupt personal keys fail closed without silent shared-key spending. Preserve environment separation, private/no-store, field/capture exclusion, deletion/offboarding and deliberate rotation/re-entry. Runtime compromise can still expose decrypted keys. Source: docs/meshy-api-keys.md.

### S05: Verified agent access boundary

OAuth/PKCE, named revocable grants, short-lived browser leases, explicit window/session pairing. Capture needs scope AND window opt-in; write access retains app/admin authorization. PR #69 aligns pairing expiry to registration expiry; one-use code remains ten minutes. Draft #70 fixes failed-pairing consent consumption. Real-client production acceptance remains unknown. Sources: docs/mcp-pilot.md, PR #69/#70, remote service.js.

### S06: Verified metadata inconsistency

auth.sign_out is registered mutates:false despite older prose saying true. Nonmutating flags can include transient/UI/download effects. **Proposed:** audit actual effects and separate scene, remote, billing, credential, capture and admin permissions; preserve compatibility. Source: source/website/agentcommands.js.

### S07: Verified diagnostics/privacy

Sanitized logs are bounded/tab-account scoped with no automatic upload. Capture excludes private dialogs/input values but may show geometry/names/visible text. Sources: docs/error-logs.md, docs/agent-screen-capture.md.

**Verified licenses:** retain Online3DViewer MIT attribution; dependencies/assets/HDRI/fonts/decoders/fixtures have separate terms. Historical notices are not proof of rebuilt license closure. Source: THIRD_PARTY_NOTICES.md, LICENSE.md, asset notices.

**Unknown:** classification, AI processing approval, geography, standards, audit retention and customer licensing obligations.

## 9. Agentic versus deterministic allocation

**Proposed:** agents interpret intent, search capabilities/reference knowledge, compose plans/macros, explain tradeoffs and summarize authorized results. Deterministic services validate schemas/permissions, evaluate CAD/geometry, manage state/history, serialize archives, enforce quotas/throttles, render/fold, store credentials and execute remote/billed effects.

**Verified starting contract:** 250 strict commands across 22 categories; UI and commands share services. Source: command-inventory.json and docs/agent-interface.md.

**Proposed harness sequence:** discover focused schemas; inspect selected account/window/document; identify remote/destructive/paid effects; invoke shared services; poll final states; inspect result; report retained partial changes. No arbitrary evaluation/DOM automation as production API. Add operation/revision IDs and idempotency before automatic remote/billing retries.

**Unknown:** harness browser/desktop/CLI/hosted architecture and OAuth/MCP/streaming/interactive-dialog capabilities.

## 10. Preserve, redesign, defer, retire

All dispositions **Proposed** unless explicitly verified limitations:

- Preserve archive compatibility and Packaging deterministic core.
- Redesign UI framework while preserving workflows/state/accessibility.
- Replace identity/hosting adapters independently while preserving ownership/security.
- Evaluate alternate backend before adoption; it lacks established full deployed parity.
- Retain legacy read compatibility until dependency audit; zero table rows is insufficient retirement evidence.
- Do not reproduce prototype grants or duplicate obsolete auth systems.
- Keep historical SQL as history, not migration runner (Verified instruction).
- Carry Primary Products draft scope only; complete CPG authoring is not established.
- Defer AR, mobile archive variants, multipart/resumable large uploads, full organization lifecycle and arbitrary custom-dieline fold inference unless separately scoped.
- Design scheduled share cleanup as an operational improvement.

No user-facing feature retirement is approved by this assessment. Sources: GOAL.md, docs/primary-products-build-plan.md, docs/share-optimization-review.md, docs/audience-sharing.md, docs/pr16-reconciliation.md.

## 11. Conflicts and unresolved evidence

| Conflict | Interpretation |
|---|---|
| Format doc v4 vs source v5 | Follow implementation/tests; update prose |
| README unsigned device/file vs current login gating | Preserve verified gating unless deliberately changed |
| Old material Undo exclusions vs later services/tests | Inventory operation-specific current history |
| AGENTS/README/status release generations | Pin code and served deployment separately |
| Old public browsing/privacy vs newer account/audience design | Current middleware/exact exceptions govern |
| Primary Products PRs merged into stacked bases | Merge status alone does not prove presence on main |
| Key docs say not deployed vs merged PR | Deployment and real-key acceptance unconfirmed |
| Old stability report vs current mitigations | Current source has bounds cache, worker recovery, drag cleanup and coalesced rendering |
| Build prose avoids repeat checks vs production workflow | Actual workflow includes substantial validation |

Sources: source/website/sessionarchive.js, README.md, AGENTS.md, docs/project-status.md, docs/build-maintenance.md, source/website/sessioneditor.js, source/engine/viewer/viewer.js, PR #62/#64, workflows. **Proposed:** record discrepancies in decisions; do not promote stale prose or feature-branch claims into requirements.

## 12. Implementation-ready backlog

All work packages **Proposed**:

| Order | Work | Dependencies | Acceptance |
|---|---|---|---|
| P0-01 | Freeze source/deployment/scope | None | Pinned manifest and differences |
| P0-02 | Schema/bootstrap/permissions | 01 | Disposable clean schema/RPC/grant match |
| P0-03 | Golden document corpus | 01 | Old/current/malformed/animated/profile-only outcomes |
| P0-04 | Document/units/scene/history/import | 03 | Semantic round trips; atomic failures |
| P0-05 | Packaging/engineering | 04 | Formula/vector/topology/fold/history independent + host |
| P0-06 | Identity/private persistence | 02 | Account denial/revoke/quota concurrency/cleanup |
| P0-07 | Device/recovery migration | 04,06 | Origin/account export/restore demonstrated |
| P0-08 | Sharing/link policy | 06 | Challenge/throttle/expiry/revoke/snapshot independence |
| P0-09 | Commands/new harness | 04,06 | Schema/permission parity and real-client acceptance |
| P1-01 | Visual/timeline/camera/render fidelity | Core | Image/state comparison |
| P1-02 | AI/credential adapters | Identity/storage | Fake provider + authorized real-key smoke |
| P1-03 | Runbooks/cutover rehearsal | All P0 | Restore/rollback/offboard/rotate/reconcile |
| P2-01 | Future scope | Product approval | Separate Primary Products/AR/org/variants decisions |

**Unknown:** reliable estimates require target harness/runtime, representative assets and agreed compatibility scope.

## 13. Validation and release gates

**Verified assessment:** application/module 720 pass, focused 22 pass, lint pass. Backend HTTP and MCP runtime blocked by environment; no browser/production smoke performed in assessment. Raw logs included.

**Proposed required scenarios:**

| Area | Acceptance cases |
|---|---|
| Documents | Old versions/newer rejection, malformed boolean, textures/animation/packaging/cameras |
| Imports/exports | Corporate format corpus, units/sidecars/material/hierarchy, rollback |
| Editing | Multi-select/groups/arrays/update/history/invalid/interrupted drag |
| Recovery | Reload, quota pressure, account switch, save/discard, large geometry |
| Packaging | Four styles, all bases, calibration rejection, tolerances, vector units, fold/cancel |
| Storage | Known-ID denial, previews, concurrent quota, failed write/delete, pending cleanup, partial folders |
| Sharing | Leading zeros, incorrect/correct challenge, actor/global lock, expiry, revoke-during-create, download |
| Rendering | UV/original maps, relief/varnish restore, HDRI outage, context lifecycle, alpha/cancel |
| AI | No task on open, duplicate prevention, poll failures, account switch, expired URLs, complete project |
| Credentials | No logs/capture/persistence leakage, tamper/account binding, missing secret, rotate/offboard |
| Agents | PKCE/consent/callback, window/tab/account change, stale delivery, scope separation/revoke |
| Deployment | Served version/commit/hash, worker/decoder/module presence, public/private boundaries |

Passing mocks is necessary but insufficient. Require actual harness client, authorized production smoke, representative CAD UAT and desktop/mobile checks.

## 14. Cutover, operations and rollback

**Verified:** main-triggered Pages deployment builds/validates, deploys and probes served identity plus selected Meshy/MCP boundaries. Main/mini/workers/decoders/lazy module assets deploy together. Sources: .github/workflows/cloudflare-pages.yml, docs/agent-project-overview.md.

**Proposed cutover:** isolated environment; disposable identities/authorized copies; semantic/image comparison; restore/pending-reconcile rehearsal; real-user/client pilot; device export before origin change; consistent backup/final reconcile; gated traffic switch; served identity/journey checks; retain old app/data for rollback window.

**Proposed rollback triggers:** ownership leak, unrecoverable document loss, engineering mismatch, failed revoke, credential exposure, unacceptable visual degradation.

**Required runbooks:** upload/pending/orphan reconciliation; DB/R2 backup/restore; disable/revoke/offboard; audience expiry/reclaim; AI key removal/rotation; OAuth revoke/reauthorize; context/large-file diagnostics; deployment verify/rollback.

**Unknown:** operational ownership/on-call, billing limits, monitoring/alerts, backup retention.

## 15. Decisions before implementation commitments

1. Harness and supported clients/environments.
2. Actual business-critical workflows and acceptance owners.
3. Existing share URL/agent grant continuity.
4. Hosting/identity migration scope and timing.
5. Representative real-file fidelity corpus.
6. AI spending/data processing policy.
7. Retention/audit/availability/recovery requirements.
8. Primary Products draft versus completed feature scope.
9. Performance/device targets.
10. Authority for behavior changes/retirement.

Until resolved, preserve current data/security contracts and compatibility adapters; keep roadmap work outside parity commitments.

## 16. Conversation context: previous assistant response

Included at the user's request. The following is the assistant's previous response verbatim. Its file count describes the ZIP before this documentation update; MANIFEST.json describes the current package.

> Created `Auto3D-Rebuild-Handoff.zip` in `/workspace/output/`.
>
> Includes 161 files: consolidated handoff, supporting documents, command catalog, evidence, and validation logs. Integrity checks passed.
>
> The configured download folder is inaccessible, so the ZIP remains in the workspace.

The preceding sections retain the architectural, product, migration, evidence, and validation context from the earlier comprehensive assessment. Packaging this material does not change its evidence status or establish production acceptance.
