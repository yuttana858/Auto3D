# Auto3D movement and high polygon stability review

Scope: source review and CPU measurements in the cloud environment. No application code changed. Browser GPU profiling and reproduction with the user's model were not performed.

## Findings, in priority order

1. **High: each gizmo move performs a complete vertex scan.** `source/website/sessioneditor.js:77` calls `SyncInputs`, which always calls `GetObjectBaseSize` (`:488`, `:508`). That method clones the object hierarchy and calls `Box3.setFromObject(clone, true)`. The `true` flag forces precise vertex evaluation, even for translation and rotation, where the untransformed base dimensions have not changed. This synchronous work scales with vertex count and mesh count, allocates object clones, and runs for every pointer event. Cache base dimensions when geometry changes; invalidate for replacement/deformation as appropriate. Transform edits should reuse the cache. Coalesce input updates and renders into one animation frame while retaining the final transform.

2. **High: recovery creates a synchronous, multi-second main-thread stall after edits.** `sessioneditor.js:317` schedules `SaveRecovery` after 1500 ms. Transform history triggers that path through `SceneHistory.Changed`. `SaveRecovery` calls `Archive` synchronously before its first await. `PackSession` expands geometry into JavaScript arrays, then `CreateSessionArchive` (`sessionarchive.js:239`) runs `JSON.stringify`, UTF-8 encoding, and `zipSync`. Declaring the caller async does not move this work off-thread. Repeated edits therefore reserialize unchanged geometry, with substantial transient memory use. A pending timer can also run during a subsequent drag. Move serialization/compression off the UI thread, avoid duplicating static geometry on transform-only checkpoints, serialize jobs, and postpone checkpoints during interaction. Preserve crash recovery rather than simply disabling it.

3. **High, reproduction needed: interrupted drag can strand navigation in a disabled state.** `sessioneditor.js:72` sets `navigation.enabled = !event.value` and relies on TransformControls emitting the drag-end event to restore it. Installed Three.js TransformControls handles pointerup but registers no pointercancel/lostpointercapture handler; the editor also has no blur/cancel recovery for the main gizmo. A canceled touch/pen interaction or lost pointer sequence can leave dragging true and navigation disabled. Add one idempotent drag finalizer shared by normal release, cancellation, lost capture and blur. Verify exactly one history record and final state synchronization. The preview's separate pointercancel handler does not cover the main gizmo.

4. **Medium: optional effects and immediate rendering amplify expensive operations.** `viewer.js:549` renders synchronously. Gizmo change events request a render per event; camera mouse moves also render immediately. Numeric transforms call `SceneEffects.Refresh`, whose `Update` renders, then explicitly render again. With model reflections enabled, Update performs a six-face cube capture, scans precise scene bounds, changes material env maps and marks materials for update. Floor reflections add a scene render, and shadows add shadow-map work. Effects default off, so they do not explain every freeze. Reuse bounds per update, coalesce renders, throttle reflection capture and reduce optional effect quality during interaction.

5. **Medium: detail preview adds another GPU context and geometry upload.** `sessioneditor.js:664` creates a separate WebGLRenderer and clones the full model, even without a check for whether Model Data is expanded. Although the clone shares CPU geometry/material references, the separate renderer has separate GPU resources. This increases GPU memory pressure for large models. Create/render the preview only when visible, use a proxy or reduced-detail model, and handle context loss explicitly. No application-level context-loss feedback was found.

## CPU measurements

Node.js cloud microbenchmark, seven size measurements per target; synthetic single-mesh, non-indexed geometry with three unique vertices per triangle. Archive input used geometry-shaped vertex and triangle arrays. Archive timing includes JSON/UTF-8/ZIP only, not actual PackSession, textures, animations, IndexedDB or GPU rendering. Results are evidence of synchronous cost, not browser FPS or a universal polygon limit.

| Triangles | Actual GetObjectBaseSize median | Cached geometry box union median | JSON + ZIP | ZIP size |
| ---: | ---: | ---: | ---: | ---: |
| 100,000 | 6.19 ms | 0.023 ms | 1.25 s | 7.53 MiB |
| 500,000 | 31.42 ms | 0.038 ms | 6.58 s | 37.66 MiB |
| 1,000,000 | 62.78 ms | 0.039 ms | 13.24 s | 75.31 MiB |

Cached boxes can overestimate rotated geometry bounds; they are not a drop-in replacement where exact dimensions are required. Cache exact base dimensions and use conservative transformed bounds for interaction helpers.

## Recommended validation for fixes

- Drag translate/rotate/scale across 100k, 500k and 1M triangle models; also test many separate meshes and textured assets. Capture frame time, long tasks and memory on the target browser/hardware.
- Interrupt drag with pointercancel, lost capture and window blur. Verify navigation resumes, controls stop dragging, and undo remains correct.
- Test a second drag while recovery is due. Verify UI responsiveness, single-flight recovery, restored transforms and error handling under storage quota pressure.
- Compare reflection/shadow settings off and on; test Model Data collapsed versus expanded. Watch GPU/context-loss behavior and repeated preview opening.
- Run existing session/workspace/animation regressions and a real browser interaction test. Current CPU results do not establish WebGL stability or the user's exact failure trigger.

Immediate mitigation: leave realtime model reflections, floor reflections and shadows off for large assets and reduce model detail where possible. A repeatable freeze about 1.5 seconds after releasing the gizmo strongly implicates recovery; sluggishness throughout the drag implicates size scans/rendering; permanent loss of navigation after an interrupted drag implicates cleanup.
