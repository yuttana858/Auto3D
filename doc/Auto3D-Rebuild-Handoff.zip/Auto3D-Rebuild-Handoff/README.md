# Auto3D migration handoff bundle

Start with **Auto3D-Rebuild-Handoff.md**. It compiles the architecture/product/migration assessment from chat into one document with evidence labels, capability inventory, compatibility contracts, risks, priorities, acceptance criteria and cutover guidance.

## Contents

- Auto3D-Rebuild-Handoff.md — consolidated handoff.
- UI-UX-Screenshot-Catalog.md — catalog/analysis of ten user-supplied screenshots, including Welcome/Preferences; original image files remain in chat, not in this ZIP.
- Source-Index.md — pinned source references and included-document index.
- command-inventory.json — complete existing 250-command catalog with schemas.
- command-inventory.csv — searchable command inventory.
- repository-documents/ — repository documentation, notices, workflow configuration, and schema reference files, copied without editorial changes.
- evidence/ — assessment-time database/repository metadata and supplied historical stability review.
- validation/ — assessment test/lint logs, including environment-blocked checks.
- MANIFEST.json — per-file SHA-256 and byte sizes.

## Important interpretation

Assessment date: November 5, 2026. Source checkout: 716ed51b48f88caeb5b147e1d4b6cc206c35358e. Remote main observed at 8697574620d7d11a1e3532dfdacd0d20e42b293b. Production deployment identity was not established. Recommendations are proposed, not approved feature retirements.

Historical docs can conflict with current code. SQL files are reference evidence, **not an executable bootstrap**; historical PR16 SQL must not be replayed. No credentials, environment secret files, production model contents, or full source repository are included. Existing test fixtures and external live services were not exported.

Visual addendum: ten desktop screenshots were subsequently supplied by the user and inspected in chat. The catalog records source-image order, visible states, evidence limits, migration requirements and coverage gaps. Earlier no-screenshot statements describe the original assessment. No screenshot binary files are included. Access code/link/QR contents and personal names were not transcribed. Preferences visibly reports v0.47.6/build 0ffd76defb75157f3c701b2360e8939d14ebdf6e, Standard (in) and Auto viewport quality; these do not constitute independent live acceptance.

Validation: 720 application/module tests and lint passed; 22 focused tests passed. Backend HTTP/MCP runtime checks were blocked by local socket restrictions. No real-client, paid-generation, production browser or physical-device acceptance is claimed.
